import shutil
import time

from permissions import PermissionsResource
from database import database

from androwarn.warn.report.report import generate_report
from androwarn.warn.analysis.analysis import perform_analysis
from androwarn.warn.search.search import grab_application_package_name
import json
from androguard.misc import AnalyzeAPK
import os
import Report as rp
from shutil import copyfile
#import callthereport
import glob

from json2html import *

class process(object):
    permissions_service = PermissionsResource()
    database_service = database()
    upload_directory_base = "./Files"

    def process_apk(self):
        import ModelPredictions as mp
        #print "here"
        taks_list = self.database_service.get_processing()
        print taks_list
        for records in taks_list:
            apk_id = records[0]
            apk_name = records[2]
            file_dir = self.upload_directory_base + "/" + str(apk_id) + "/"
            file_path = file_dir + apk_name
            a, d, dx = AnalyzeAPK(file_path)
            permissions = self.permissions_service.getPermissions(a)
            print permissions
            features = permissions.split(',')
            features =  mp.mlpredict(features)
            # print permissions
            package_name = grab_application_package_name(a)
            data = perform_analysis(file_path, a, d, dx, False)
            # 'Verbosity level (ESSENTIAL 1, ADVANCED 2, EXPERT 3) (default 1)'
            generate_report(package_name, data, 1, 'html', file_dir + 'index.html')
            generate_report(package_name, data, 1, 'json', file_dir + 'index.json')
            # SUPER report and send back in the body



            command = "super\super-analyzer --json --results " + file_dir + " " + file_path
            os.system(command)

            for name in os.listdir(file_dir):
                if os.path.isdir(os.path.join(file_dir, name)):
                    filesrc = os.path.join(file_dir, name)
                    filesrc = os.path.join(filesrc, "results.json")
                    shutil.copy(filesrc, file_dir)
                    #copyfile(os.path.join(file_dir, name + "/results.json"),file_dir)
                    #copyfile(file_dir + "/ " + name, file_dir)

            json1 = file_dir + "results.json"
            json2 = file_dir + "index.json"
            final = file_dir + "finalReport.html"
            with open(json1) as json_data:
                d = json.load(json_data)
                json_data.close()
            with open(json2) as json_data1:
                d2 = json.load(json_data1)
                json_data1.close()

            rp.Reportgen(d,d2,features,final)


            self.database_service.update_record(apk_id,"Finished")
            time.sleep(2)



process_ins = process()
process_ins.process_apk()
