import os
import time

while True:
    print "working"
    command = "python process.py"
    os.system(command)
    print "sleep"
    time.sleep(10)
