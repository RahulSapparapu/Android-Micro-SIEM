from json2html import *

def Reportgen(json1,json2,ml,filename):
	output = filename
	f = open(output, "a")
	f.write("""<p align="center"><img src="D:\downloads\Dhakka-master\Dhakka-master\hga.png" alt="Paris" class="center"> </p>
  <h1 align="center"> COMPILED REPORT - PROJECT ANDRODOCTOR</h1>
  <link rel="stylesheet" href="D:\downloads\Dhakka-master\Dhakka-master\styles.css">""")
	f.write(json2html.convert(json = json1).encode('utf-8').strip())
	f.write("\n PART 2")
	f.write(json2html.convert(json = json2).encode('utf-8').strip())
	f.write("""<table>
  <thead>
    <tr>
      <th>Malicious Intent Detector Using ML</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>""")
      
    
	for val in ml:
		if val[0]==1:
			result="No Malicious or Data Theft Intent with Prob : "
		else:
			result="Malicious or Data Theft Intent with Prob : "
		f.write(result+str(val[1])+'</td><td>')

	f.write("""</td></tr>
      
  </tbody>
</table>""")
	f.close()