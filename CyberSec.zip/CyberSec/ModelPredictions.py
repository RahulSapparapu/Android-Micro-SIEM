import pandas as pd
import numpy as np
import pickle
def mlpredict(features):
	result=[]
	with open("decisionboundary.pckl", "rb") as f:
	    while True:
	        try:
	            clf=pickle.load(f)
	        except EOFError:
	            break
	pred = clf.predict([features])
	result.append([pred[0],int(100*clf.predict_proba([features])[0][pred[0]-1])])
	
	with open("ensemblelearning.pckl", "rb") as f:
	    while True:
	        try:
	            clf=pickle.load(f)
	        except EOFError:
	            break
	pred = clf.predict([features])
	result.append([pred[0],int(100*clf.predict_proba([features])[0][pred[0]-1])])


	with open("instancebased.pckl", "rb") as f:
	    while True:
	        try:
	            clf=pickle.load(f)
	        except EOFError:
	            break
	pred = clf.predict([features])
	result.append([pred[0],int(100*clf.predict_proba([features])[0][pred[0]-1])])


	return result